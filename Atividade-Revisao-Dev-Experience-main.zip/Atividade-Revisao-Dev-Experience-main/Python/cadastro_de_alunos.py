alunos = {
    "Vinicius": {"idade": 18, "curso": "Desenvolvimento de Sistemas"},
    "Maria": {"idade": 20, "curso": "Engenharia"},
    "João": {"idade": 22, "curso": "Medicina"}
}

while True:
    print("\nEscolha uma das opções abaixo")
    print("1 → Cadastrar aluno")
    print("2 → Listar todos os alunos")
    print("3 → Pesquisar aluno por nome")
    print("4 → Sair")

    escolha = input("Digite sua opção: ")

    if escolha == "1":
        nome = input("Digite o nome do aluno: ")
        idade = input("Digite a idade do aluno: ")
        curso = input("Digite o curso do novo aluno: ")
        
        alunos[nome] = {"idade": idade, "curso": curso}
        print("Aluno adicionado com sucesso!")

    elif escolha == "2":
        if not alunos:
            print("Nenhum aluno cadastrado.\n")
        else:
            print("\n Lista de Alunos:")
            for i, (nome, dados) in enumerate(alunos.items(), start=1):
                print(f"{i}. Nome: {nome}, Idade: {dados['idade']}, Curso: {dados['curso']}")
                
    elif escolha == "3":
        nome_busca = input("Digite o nome do aluno para pesquisar: ")
        if nome_busca in alunos:
            dados = alunos[nome_busca]
            print(f"Encontrado → Nome: {nome_busca}, Idade: {dados['idade']}, Curso: {dados['curso']}")
        else:
            print("Aluno não encontrado.")
        
    elif escolha == "4":
        print("Processo encerrado. Até mais!")
        break
        
    else:
        print("Escolha inválida, tente novamente.")
